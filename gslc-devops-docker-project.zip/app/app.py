from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return "GSLC DevOps Project - Simple Web Application"

@app.route("/info")
def info():
    return "This project demonstrates GitHub collaboration and Docker implementation."

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
