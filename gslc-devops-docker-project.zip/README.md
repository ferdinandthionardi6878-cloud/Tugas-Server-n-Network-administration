# GSLC DevOps Docker Project

Repository ini dibuat untuk memenuhi tugas GSLC mengenai implementasi DevOps menggunakan GitHub collaboration dan Docker.

## Deskripsi Project

Project ini merupakan aplikasi web sederhana menggunakan Python Flask yang dijalankan menggunakan Docker container. Tujuan utama dari project ini adalah untuk mempraktikkan konsep DevOps seperti kolaborasi repository, pull request, serta penggunaan Docker untuk menjalankan aplikasi.

## Teknologi yang Digunakan

- Python
- Flask
- Docker
- Docker Compose
- GitHub

## Cara Instalasi

Pastikan software berikut sudah terinstall:

- Git
- Docker
- Docker Compose

## Clone Repository

git clone https://github.com/username/gslc-devops-docker-project.git

Masuk ke folder project:

cd gslc-devops-docker-project

## Menjalankan Project Menggunakan Docker

Build docker image:

docker build -t gslc-devops .

Menjalankan container:

docker run -p 5000:5000 gslc-devops

Setelah container berjalan, buka browser dan akses:

http://localhost:5000

## Menjalankan Menggunakan Docker Compose

Untuk menjalankan menggunakan docker compose gunakan perintah:

docker-compose up --build

## Kolaborasi Project

Repository ini mendukung kolaborasi antar anggota kelompok melalui GitHub. Setiap anggota dapat membuat branch sendiri lalu melakukan pull request sebelum digabungkan ke branch utama.

Contoh workflow kolaborasi:

1. Membuat branch baru
2. Melakukan perubahan pada project
3. Commit perubahan
4. Push ke repository
5. Membuat pull request

## Kesimpulan

Project ini menunjukkan bagaimana proses kolaborasi menggunakan GitHub serta bagaimana aplikasi sederhana dapat dijalankan menggunakan Docker container.
